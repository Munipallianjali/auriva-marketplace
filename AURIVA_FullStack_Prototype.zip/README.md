# AURIVA Full-Stack Prototype

## Run locally
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:
   npm install
   npm start
4. Open http://localhost:3000

## Included
- Node.js + Express backend
- REST APIs for products, sellers, orders, dashboard
- JSON persistence in `data.json`
- Admin dashboard UI
- Product studio
- Seller onboarding
- Order stream
- AI Studio / explainable marketplace analysis
- Distinctive aesthetic patterns and responsive layout

## AI note
The included AI engine is a local, explainable analytics prototype. It does not require an external AI key. It uses marketplace signals such as trend scores, stock, orders, revenue and category momentum.

For production AI, replace `/api/ai/ask` and/or `aiInsights()` with a hosted model integration, while keeping secrets in environment variables.
